# Shadow Copy 👻🐈

A minimalist neon browser game — collect orbs, avoid your own shadow clones (and the red hunter ghosts), survive as long as you can. Pure HTML/CSS/JS, no backend, no build step.

## Play locally
Just open `index.html` in any browser (desktop or mobile).

## Deploy to GitHub
1. Create a new repository on GitHub (e.g. `shadow-copy`).
2. Upload all the files in this folder (`index.html`, `style.css`, `script.js`, `vercel.json`, `README.md`) to the repo — either drag-and-drop on github.com, or via git:
   ```bash
   git init
   git add .
   git commit -m "Shadow Copy game"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/shadow-copy.git
   git push -u origin main
   ```

## Deploy to Vercel
**Option A — from GitHub (recommended, auto-redeploys on future pushes):**
1. Go to [vercel.com](https://vercel.com) → New Project.
2. Import the GitHub repo you just created.
3. Framework preset: choose **"Other"** (it's a static site, no build step needed).
4. Click Deploy. You'll get a live URL like `shadow-copy.vercel.app`.

**Option B — direct upload (no GitHub needed):**
1. Go to [vercel.com](https://vercel.com) → New Project → "Deploy" tab → drag and drop this whole folder.
2. Click Deploy.

That's it — no environment variables, no API keys, no database. 100% free to host on Vercel's Hobby tier.

## Notes
- High scores are saved locally per-device via `localStorage` — they are **not** shared between players.
- Works on both desktop (WASD / Arrow Keys) and mobile (on-screen joystick, auto-detected via touch).
